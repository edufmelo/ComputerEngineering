<?php
    $url = "Location: /ClinicaA/medListar.php";	// Monta página para redirecionamento
    header($url);
?>