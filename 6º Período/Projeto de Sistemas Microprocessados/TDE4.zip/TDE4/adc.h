/*
 * adc.h
 *
 * Created: 30/10/2024 16:06:56
 *  Author: afonsomiguel
 */ 


#ifndef ADC_H_
#define ADC_H_

void configura_adc();
unsigned int le_adc();


#endif /* ADC_H_ */