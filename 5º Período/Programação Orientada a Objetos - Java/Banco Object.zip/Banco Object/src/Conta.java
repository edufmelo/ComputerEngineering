import java.time.LocalDate;
import java.util.ArrayList;
import java.util.regex.Pattern;

public abstract class Conta implements Comparable<Conta> {
    private int numeroConta;
    private String nomeCorrentista;
    private String cpfCorrentista;
    private String senhaConta;
    private float saldo;
    private ArrayList<Operacao> operacoes;

    public Conta(int numeroConta, String nomeCorrentista, String cpfCorrentista, String senhaConta) {
        this.numeroConta = numeroConta;
        this.nomeCorrentista = nomeCorrentista;
        this.cpfCorrentista = cpfCorrentista;
        this.senhaConta = senhaConta;
        this.saldo = 0.0f;
        this.operacoes = new ArrayList<>();
    }

    public String getSenhaConta() {
        return senhaConta;
    }

    public void setSenhaConta(String senhaConta) {
        this.senhaConta = senhaConta;
    }

    public int getNumeroConta() {
        return numeroConta;
    }

    public String getNomeCorrentista() {
        return nomeCorrentista;
    }

    public String getCpfCorrentista() {
        return cpfCorrentista;
    }

    public float getSaldo() {
        return saldo;
    }

    public ArrayList<Operacao> getOperacoes() {
        return operacoes;
    }

    public void depositar(float valor) {
        if (valor > 0) {
            this.saldo += valor;
            this.operacoes.add(new Operacao(LocalDate.now(), valor, "Depósito"));
        } else {
            throw new IllegalArgumentException("O valor do depósito deve ser positivo.");
        }
    }

    public void sacar(float valor) {
        if (valor > 0 && valor <= this.saldo) {
            this.saldo -= valor;
            this.operacoes.add(new Operacao(LocalDate.now(), valor, "Saque"));
        } else if (valor > this.saldo) {
            throw new IllegalArgumentException("Saldo insuficiente para saque.");
        } else {
            throw new IllegalArgumentException("O valor do saque deve ser positivo.");
        }
    }

    public static boolean isCpfValido(String cpf) {
        return Pattern.matches("\\d+", cpf);
    }

    public float efetuarPix(float valor) {
        sacar(valor);
        return valor;
    }

    public void receberPix(float valor) {
        depositar(valor);
    }

    @Override
    public int compareTo(Conta outraConta) {
        return Integer.compare(this.numeroConta, outraConta.numeroConta);
    }
}
