public class Poupanca extends Conta implements Remunerada {
    public Poupanca(int numeroConta, String nomeCorrentista, String cpfCorrentista, String senhaConta) {
        super(numeroConta, nomeCorrentista, cpfCorrentista, senhaConta);
    }

    public void aplicarCorrecao(float taxa) {
        if (taxa > 0) {
            float saldoAtual = getSaldo();
            float valorCorrecao = saldoAtual * (taxa / 100);
            depositar(valorCorrecao);
        } else {
            throw new IllegalArgumentException("Taxa de correção deve ser positiva.");
        }
    }
}
