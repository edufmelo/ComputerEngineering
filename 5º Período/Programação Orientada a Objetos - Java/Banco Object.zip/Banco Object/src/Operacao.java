import java.time.LocalDate;
import java.util.Date;

public class Operacao {
    private LocalDate data;
    private float valor;
    private String tipo;

    public Operacao(LocalDate data, float valor, String tipo) {
        this.data = data;
        this.valor = valor;
        this.tipo = tipo;
    }

    public LocalDate getData() {
        return data;
    }

    public float getValor() {
        return valor;
    }

    public String getTipo() {
        return tipo;
    }
}
