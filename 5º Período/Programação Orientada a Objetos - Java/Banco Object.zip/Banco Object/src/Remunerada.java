public interface Remunerada {
    void aplicarCorrecao(float taxa);
}
